//
//  ViewControllerC.swift
//  PageViewController
//
//  Created by eric on 2022/11/27.
//

import Foundation
import UIKit

class ViewControllerC: UIViewController  {
    private let label = UILabel()
    
    required override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        view.bounds = CGRect(x: 0, y: 0, width: SCREENWIDTH, height: SCREENHEIGHT)
        view.addSubview(label)
        label.text = "This is a test C"
//        label.translatesAutoresizingMaskIntoConstraints = false
        
        label.layer.position = view.layer.position
        label.bounds = CGRect(x: 0, y: 0, width: 200, height: 100)
        
//        let width: NSLayoutConstraint = NSLayoutConstraint(item: label, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 0.0, constant: 200)
//        label.addConstraint(width)
//
//        let height: NSLayoutConstraint = NSLayoutConstraint(item: label, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 0.0, constant: 100)
//        label.addConstraint(height)
//
//        let centerX: NSLayoutConstraint = NSLayoutConstraint(item: label, attribute: .centerX, relatedBy: .equal, toItem: view, attribute: .centerX, multiplier: 1.0, constant: 0.0)
//        label.superview?.addConstraint(centerX)
//
//        let centerY: NSLayoutConstraint = NSLayoutConstraint(item: label, attribute: .centerY, relatedBy: .equal, toItem: view, attribute: .centerY, multiplier: 1.0, constant: 0.0)
//        label.superview?.addConstraint(centerY)
        
        self.view.backgroundColor   = .yellow
//        self.view.translatesAutoresizingMaskIntoConstraints = false
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
