//
//  ViewController.swift
//  PageViewController
//
//  Created by eric on 2022/11/26.
//

import UIKit
let tabNumber: CGFloat = 3
let SCREENWIDTH: CGFloat = UIScreen.main.bounds.width
let SCREENHEIGHT: CGFloat = UIScreen.main.bounds.height

class ViewController: UIViewController,UIScrollViewDelegate {
    
    private var ViewControllerFirst = ViewControllerA(nibName: nil, bundle: nil)
    private var ViewControllerSecond = ViewControllerB(nibName: nil, bundle: nil)
    private var ViewControllerThird = ViewControllerC(nibName: nil, bundle: nil)
    
    private var currentIndex = 0
    
    private var vcArray: [UIView] = []
    
    private var isDragging = false
    private var lastContentOffset = CGPoint(x: 0, y: 0)
    
    private var scrollBaseView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.contentSize = CGSize(width: tabNumber * UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        scrollView.frame = CGRect(x: 0, y: 0, width: SCREENWIDTH, height: SCREENHEIGHT)
        scrollView.alwaysBounceHorizontal = true
        scrollView.isScrollEnabled = true
        //scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.isPagingEnabled = true
        return scrollView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        view.addSubview(scrollBaseView)
        
        vcArray = [ViewControllerFirst.view, ViewControllerSecond.view, ViewControllerThird.view]
        
        updateViewScrollView()
        
        scrollBaseView.contentOffset = CGPoint(x: SCREENWIDTH, y: 0)
    }
    
    private func updateViewScrollView() {
        
        let layoutLeftIndex = (currentIndex - 1) < 0 ? (vcArray.count - 1) : (currentIndex - 1)
        let layoutRightIndex = (currentIndex + 1) >= vcArray.count ? 0 : (currentIndex + 1)
            
        let curView = vcArray[currentIndex]
        let leftView = vcArray[layoutLeftIndex]
        let rightView = vcArray[layoutRightIndex]
            
        leftView.center = CGPoint(x: SCREENWIDTH/2, y: SCREENHEIGHT/2)
        curView.center = CGPoint(x: 3*SCREENWIDTH/2, y: SCREENHEIGHT/2)
        rightView.center = CGPoint(x: 5*SCREENWIDTH/2, y: SCREENHEIGHT/2)

        scrollBaseView.addSubview(leftView)
        scrollBaseView.addSubview(curView)
        scrollBaseView.addSubview(rightView)
        
        scrollBaseView.contentOffset = CGPoint(x: SCREENWIDTH, y: 0)
        
    }
    

    
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        isDragging = true
        lastContentOffset = scrollView.contentOffset
    }
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        
        if isDragging == false {
            return
        }
    
        isDragging = false
        
        print("move distance:\(abs((scrollView.contentOffset.x - lastContentOffset.x)))")
        guard abs((scrollView.contentOffset.x - lastContentOffset.x)) > SCREENWIDTH/4 else {
            scrollView.contentOffset = lastContentOffset
            return
            
        }
        
        if scrollView.contentOffset.x >= UIScreen.main.bounds.width,
           scrollView.contentOffset.x < 2 * UIScreen.main.bounds.width {
            currentIndex = (currentIndex + 1)%3
        } else if scrollView.contentOffset.x < UIScreen.main.bounds.width {
            currentIndex = (currentIndex - 1)<0 ? ((currentIndex - 1)+3)%3 : (currentIndex - 1)
        }
        
        print("scrollViewDidEndDragging current Index:\(currentIndex)")
        updateViewScrollView()
        
    }
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        
    }
    
    func scrollViewWillBeginDecelerating(_ scrollView: UIScrollView) {
        print("scrollViewWillBeginDecelerating_current Index:\(currentIndex)")
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        print("scrollViewDidEndDecelerating_current Index:\(currentIndex)")
        updateViewScrollView()
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        
        
//        guard

        switch currentIndex {
        case 0:
            
            break
        case 1:
            break
        case 2:
            break
        default:
            break
        }
        
    }
}

